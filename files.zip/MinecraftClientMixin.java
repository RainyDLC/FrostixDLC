package frostix.mixin;

import frostix.menu.CustomMainMenuScreen;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(MinecraftClient.class)
public abstract class MinecraftClientMixin {

    /** Любой переход на ванильное главное меню заменяем на наше. */
    @ModifyVariable(method = "setScreen", at = @At("HEAD"), argsOnly = true)
    private Screen frostix$replaceTitleScreen(Screen screen) {
        if (screen instanceof TitleScreen) return new CustomMainMenuScreen();
        return screen;
    }
}
