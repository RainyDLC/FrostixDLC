package frostix.menu;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

/** Настройки главного меню. Хранятся в .minecraft/config/frostix_mainmenu.json */
public final class MenuConfig {

    public enum BgType { DEFAULT, IMAGE, VIDEO }

    /** Позиция элемента: доли экрана (чтобы переживать смену GUI scale) + размер в пикселях. */
    public static final class Pos {
        public float fx, fy;
        public int w, h;
        public Pos() {}
        public Pos(float fx, float fy, int w, int h) { this.fx = fx; this.fy = fy; this.w = w; this.h = h; }
    }

    public BgType bgType = BgType.DEFAULT;
    public String bgPath = "";
    public float dim = 0.25f;
    public boolean particles = true;
    public boolean snap = true;
    public int accent = 0xFF3B82F6;
    public String clientName = "Frostix Client";
    public Map<String, Pos> pos = new LinkedHashMap<>();

    // ---------------------------------------------------------------------

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static MenuConfig instance;

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("frostix_mainmenu.json");
    }

    public static MenuConfig get() {
        if (instance == null) instance = load();
        return instance;
    }

    private static MenuConfig load() {
        try {
            Path f = file();
            if (Files.isRegularFile(f)) {
                MenuConfig c = GSON.fromJson(Files.readString(f), MenuConfig.class);
                if (c != null) {
                    if (c.pos == null) c.pos = new LinkedHashMap<>();
                    if (c.bgType == null) c.bgType = BgType.DEFAULT;
                    if (c.bgPath == null) c.bgPath = "";
                    return c;
                }
            }
        } catch (Exception ignored) {}
        return new MenuConfig();
    }

    public void save() {
        try {
            Files.writeString(file(), GSON.toJson(this));
        } catch (IOException ignored) {}
    }

    public void reset() {
        MenuConfig d = new MenuConfig();
        bgType = d.bgType;
        bgPath = d.bgPath;
        dim = d.dim;
        particles = d.particles;
        snap = d.snap;
        accent = d.accent;
        pos.clear();
        save();
    }

    public static boolean isVideo(String path) {
        String s = path.toLowerCase(Locale.ROOT);
        return s.endsWith(".mp4") || s.endsWith(".webm") || s.endsWith(".mkv")
                || s.endsWith(".mov") || s.endsWith(".avi") || s.endsWith(".m4v");
    }
}
