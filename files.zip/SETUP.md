# Кастомное главное меню — установка

Версия: Fabric, Minecraft 1.21.4, Yarn mappings, Java 21.

## 1. Файлы

```
src/main/java/frostix/menu/MenuConfig.java
src/main/java/frostix/menu/MenuBackground.java
src/main/java/frostix/menu/CustomMainMenuScreen.java
src/main/java/frostix/mixin/MinecraftClientMixin.java
src/main/resources/frostix.mixins.json
```

Пакеты `frostix.menu` / `frostix.mixin` замени на свои (и в mixins.json тоже).

## 2. frostix.mixins.json

```json
{
  "required": true,
  "package": "frostix.mixin",
  "compatibilityLevel": "JAVA_21",
  "client": [ "MinecraftClientMixin" ],
  "injectors": { "defaultRequire": 1 }
}
```

В `fabric.mod.json` добавь (если ещё нет):

```json
"mixins": [ "frostix.mixins.json" ]
```

## 3. build.gradle — только если нужно ВИДЕО

Фото работает без зависимостей. Для видео нужен FFmpeg через JavaCV:

```gradle
dependencies {
    // Windows x64. Для Linux/macOS замени classifier (linux-x86_64, macosx-arm64 ...)
    include(implementation("org.bytedeco:javacv:1.5.10") { transitive = false })
    include(implementation("org.bytedeco:javacpp:1.5.10"))
    include(implementation("org.bytedeco:javacpp:1.5.10:windows-x86_64"))
    include(implementation("org.bytedeco:ffmpeg:6.1.1-1.5.10"))
    include(implementation("org.bytedeco:ffmpeg:6.1.1-1.5.10:windows-x86_64"))
}
```

Если при запуске `NoClassDefFoundError` — убери `{ transitive = false }`.
Если видео не нужно — удали из `MenuBackground` метод `decodeVideo`, импорты `org.bytedeco.*`
и ветку `video` в `load()`.

## 4. Управление

- **Шестерёнка** (справа сверху) — открыть/закрыть панель настроек (Esc тоже закрывает).
- Пока панель открыта, **все кнопки и блок с заголовком двигаются мышью** (drag & drop).
- **Колёсико** над кнопкой — менять ширину.
- **Фон**: вставь путь к файлу и нажми «Применить» или просто **перетащи файл в окно игры**.
  Фото: png / jpg / bmp / gif (1-й кадр). Видео: mp4 / webm / mkv / mov (без звука, зациклено).
- Пресеты расположения: Лево / Центр / Право / Низ.
- Затемнение, частицы, привязка к сетке, цвет акцента, сброс всего.
- Всё сохраняется в `.minecraft/config/frostix_mainmenu.json`.

## 5. Что подправить под себя

- `CustomMainMenuScreen.buildElements()` — кнопка «Сменить аккаунт» пока пустая (`TODO`),
  подключи свой экран аккаунтов.
- `cfg.clientName` (в json или в `MenuConfig`) — название в заголовке.
- Новую кнопку добавить: `els.add(new El("id", "Текст", false, () -> ...))` и `place("id", ...)` в `preset()`.
