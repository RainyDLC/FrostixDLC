package frostix.menu;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;
import org.bytedeco.ffmpeg.global.avutil;
import org.bytedeco.javacv.FFmpegFrameGrabber;
import org.bytedeco.javacv.Frame;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.imageio.ImageIO;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.IntBuffer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Фон главного меню: фото (png/jpg/bmp/gif-1й кадр) или видео (mp4/webm/mkv... через JavaCV/FFmpeg).
 * Декодирование идёт в отдельном потоке, загрузка в GPU — в потоке рендера.
 */
public final class MenuBackground {

    private static final Logger LOG = LoggerFactory.getLogger("FrostixMenu");
    private static final Identifier ID = Identifier.of("frostix", "menu_bg");
    private static final int MAX_IMG_W = 2560;
    private static final int MAX_VIDEO_W = 960; // меньше = меньше нагрузка

    private record Pixels(int w, int h, int[] px) {}

    private final MinecraftClient mc = MinecraftClient.getInstance();
    private final AtomicReference<Pixels> pending = new AtomicReference<>();
    private AtomicBoolean stopFlag = new AtomicBoolean(true);
    private NativeImageBackedTexture tex;
    private int tw, th;
    private boolean started;

    public boolean isStarted() { return started; }
    public boolean ready() { return tex != null; }

    /** Запускает (пере)загрузку фона согласно конфигу. Вызывать из потока рендера. */
    public void load(MenuConfig cfg) {
        stopWorker();
        releaseTexture();
        started = true;
        if (cfg.bgType == MenuConfig.BgType.DEFAULT || cfg.bgPath.isBlank()) return;

        Path p;
        try {
            p = Path.of(cfg.bgPath.replace("\"", "").trim());
        } catch (Exception e) { return; }
        if (!Files.isRegularFile(p)) return;

        AtomicBoolean stop = new AtomicBoolean(false);
        stopFlag = stop;
        boolean video = cfg.bgType == MenuConfig.BgType.VIDEO;
        Thread t = new Thread(() -> {
            try {
                if (video) decodeVideo(p, stop); else decodeImage(p);
            } catch (Throwable e) {
                LOG.error("Не удалось загрузить фон {}", p, e);
            }
        }, "Frostix-MenuBG");
        t.setDaemon(true);
        t.start();
    }

    public void close() {
        stopWorker();
        releaseTexture();
        pending.set(null);
        started = false;
    }

    /** Заливает свежий кадр в текстуру. Вызывать каждый кадр из render(). */
    public void update() {
        Pixels f = pending.getAndSet(null);
        if (f == null) return;
        if (tex == null || tw != f.w() || th != f.h()) {
            releaseTexture();
            NativeImage img = new NativeImage(NativeImage.Format.RGBA, f.w(), f.h(), false);
            tex = new NativeImageBackedTexture(img);
            tex.setFilter(true, false);
            mc.getTextureManager().registerTexture(ID, tex);
            tw = f.w();
            th = f.h();
        }
        NativeImage img = tex.getImage();
        if (img == null) return;
        int[] px = f.px();
        int i = 0;
        for (int y = 0; y < f.h(); y++) {
            for (int x = 0; x < f.w(); x++) {
                img.setColorArgb(x, y, px[i++]);
            }
        }
        tex.upload();
    }

    /** Рисует фон в режиме "cover" (заполняет экран, обрезая лишнее). */
    public void draw(DrawContext ctx, int w, int h) {
        if (tex == null) return;
        float s = Math.max((float) w / tw, (float) h / th);
        int rw = Math.round(w / s), rh = Math.round(h / s);
        float u = (tw - rw) / 2f, v = (th - rh) / 2f;
        ctx.drawTexture(RenderLayer::getGuiTextured, ID, 0, 0, u, v, w, h, rw, rh, tw, th);
    }

    // ----------------------------------------------------------------- internals

    private void stopWorker() {
        stopFlag.set(true);
    }

    private void releaseTexture() {
        if (tex != null) {
            mc.getTextureManager().destroyTexture(ID);
            tex = null;
        }
    }

    private void decodeImage(Path p) throws IOException {
        BufferedImage src = ImageIO.read(p.toFile());
        if (src == null) throw new IOException("Неподдерживаемый формат изображения (нужен png/jpg/bmp/gif)");
        int w = src.getWidth(), h = src.getHeight();
        if (w > MAX_IMG_W) {
            int nh = h * MAX_IMG_W / w;
            BufferedImage s = new BufferedImage(MAX_IMG_W, nh, BufferedImage.TYPE_INT_ARGB);
            Graphics2D g = s.createGraphics();
            g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
            g.drawImage(src, 0, 0, MAX_IMG_W, nh, null);
            g.dispose();
            src = s;
            w = MAX_IMG_W;
            h = nh;
        }
        int[] px = src.getRGB(0, 0, w, h, null, 0, w);
        for (int i = 0; i < px.length; i++) px[i] |= 0xFF000000;
        pending.set(new Pixels(w, h, px));
    }

    private void decodeVideo(Path p, AtomicBoolean stop) throws Exception {
        try (FFmpegFrameGrabber g = new FFmpegFrameGrabber(p.toFile())) {
            g.setPixelFormat(avutil.AV_PIX_FMT_BGRA);
            g.start();
            int ow = g.getImageWidth(), oh = g.getImageHeight();
            if (ow > MAX_VIDEO_W) {
                g.stop();
                g.setImageWidth(MAX_VIDEO_W);
                g.setImageHeight((oh * MAX_VIDEO_W / ow) & ~1);
                g.start();
            }
            double fps = g.getVideoFrameRate();
            if (fps < 1 || fps > 240) fps = 30;
            int every = fps > 35 ? 2 : 1;               // 60fps видео -> грузим 30 кадров/с
            long step = (long) (1_000_000_000d / fps);
            long next = System.nanoTime();
            int n = 0, misses = 0;

            while (!stop.get()) {
                Frame f = g.grabImage();
                if (f == null || f.image == null) {     // конец файла -> зацикливаем
                    if (++misses > 3) break;
                    g.setTimestamp(0);
                    continue;
                }
                misses = 0;
                if (++n % every == 0) publish(f);

                next += step;
                long wait = next - System.nanoTime();
                if (wait > 0) Thread.sleep(wait / 1_000_000, (int) (wait % 1_000_000));
                else if (wait < -step * 5) next = System.nanoTime();
            }
        }
    }

    private void publish(Frame f) {
        int w = f.imageWidth, h = f.imageHeight;
        int strideInts = f.imageStride / 4;
        IntBuffer ib = ((ByteBuffer) f.image[0]).duplicate().rewind()
                .order(ByteOrder.LITTLE_ENDIAN).asIntBuffer(); // BGRA little-endian == ARGB int
        int[] px = new int[w * h];
        for (int y = 0; y < h; y++) ib.get(y * strideInts, px, y * w, w);
        for (int i = 0; i < px.length; i++) px[i] |= 0xFF000000;
        pending.set(new Pixels(w, h, px));
    }
}
