package frostix.menu;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

import java.nio.file.Path;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class CustomMainMenuScreen extends Screen {

    private static final int GRID = 4;
    private static final int[] ACCENTS = {
            0xFF3B82F6, 0xFF8B5CF6, 0xFFEC4899, 0xFFF97316, 0xFF22C55E, 0xFF06B6D4
    };
    private static final DateTimeFormatter CLOCK = DateTimeFormatter.ofPattern("HH:mm");
    private static final String[] GEAR = {
            "....#....",
            ".##.#.##.",
            ".#######.",
            "..##.##..",
            "####.####",
            "..##.##..",
            ".#######.",
            ".##.#.##.",
            "....#...."
    };

    private final MenuConfig cfg = MenuConfig.get();
    private final MenuBackground bg = new MenuBackground();
    private final List<El> els = new ArrayList<>();
    private final List<ClickableWidget> panelWidgets = new ArrayList<>();
    private final long t0 = System.currentTimeMillis();

    private boolean panelOpen;
    private El dragging;
    private int grabDx, grabDy;

    private TextFieldWidget pathField;
    private ButtonWidget particlesBtn, snapBtn;
    private int panelX, panelY, panelW = 176, panelH, labelBgY, labelLayoutY;

    /** Элемент меню (кнопка или блок с заголовком), который можно двигать. */
    private static final class El {
        final String id;
        final String label;
        final boolean primary;
        final Runnable action;
        int x, y, w, h;
        float hover;

        El(String id, String label, boolean primary, Runnable action) {
            this.id = id; this.label = label; this.primary = primary; this.action = action;
        }
    }

    public CustomMainMenuScreen() {
        super(Text.literal("Main Menu"));
    }

    // ================================================================= init

    @Override
    protected void init() {
        if (!bg.isStarted()) bg.load(cfg);
        buildElements();
        buildPanel();
    }

    private void buildElements() {
        els.clear();
        els.add(new El("title", null, false, null));
        els.add(new El("online", "Сетевая игра", true, () -> client.setScreen(new MultiplayerScreen(this))));
        els.add(new El("single", "Одиночная игра", false, () -> client.setScreen(new SelectWorldScreen(this))));
        // TODO: подключи сюда свой экран смены аккаунта
        els.add(new El("account", "Сменить аккаунт", false, () -> {}));
        els.add(new El("settings", "Настройки", false, () -> client.setScreen(new OptionsScreen(this, client.options))));
        els.add(new El("quit", "Выйти", false, () -> client.scheduleStop()));

        if (els.stream().anyMatch(e -> !cfg.pos.containsKey(e.id))) preset("left");
        layoutFromConfig();
    }

    private void layoutFromConfig() {
        for (El e : els) {
            MenuConfig.Pos p = cfg.pos.get(e.id);
            if (p == null) continue;
            e.w = p.w;
            e.h = p.h;
            e.x = MathHelper.clamp((int) (p.fx * width), 0, Math.max(0, width - e.w));
            e.y = MathHelper.clamp((int) (p.fy * height), 0, Math.max(0, height - e.h));
        }
    }

    private void buildPanel() {
        panelWidgets.clear();
        panelX = width - panelW - 8;
        panelY = 34;
        int iw = panelW - 16, x = panelX + 8, y = panelY + 18;

        labelBgY = y;
        y += 12;
        addPanel(ButtonWidget.builder(Text.literal("Стандартный фон"), b -> {
            cfg.bgType = MenuConfig.BgType.DEFAULT;
            cfg.bgPath = "";
            pathField.setText("");
            cfg.save();
            bg.load(cfg);
        }).dimensions(x, y, iw, 18).build());
        y += 22;

        pathField = new TextFieldWidget(textRenderer, x, y, iw, 18, Text.empty());
        pathField.setMaxLength(512);
        pathField.setPlaceholder(Text.literal("Путь или перетащи файл в окно"));
        pathField.setText(cfg.bgPath);
        addPanel(pathField);
        y += 22;

        addPanel(ButtonWidget.builder(Text.literal("Применить фото/видео"), b -> applyPath())
                .dimensions(x, y, iw, 18).build());
        y += 22;

        addPanel(new DimSlider(x, y, iw, 18));
        y += 24;

        labelLayoutY = y;
        y += 12;
        int b4 = (iw - 12) / 4;
        String[] names = {"Лево", "Центр", "Право", "Низ"};
        String[] kinds = {"left", "center", "right", "bottom"};
        for (int i = 0; i < 4; i++) {
            String kind = kinds[i];
            addPanel(ButtonWidget.builder(Text.literal(names[i]), b -> {
                preset(kind);
                layoutFromConfig();
            }).dimensions(x + i * (b4 + 4), y, b4, 18).build());
        }
        y += 22;

        int half = (iw - 4) / 2;
        particlesBtn = addPanel(ButtonWidget.builder(particlesText(), b -> {
            cfg.particles = !cfg.particles;
            b.setMessage(particlesText());
            cfg.save();
        }).dimensions(x, y, half, 18).build());
        snapBtn = addPanel(ButtonWidget.builder(snapText(), b -> {
            cfg.snap = !cfg.snap;
            b.setMessage(snapText());
            cfg.save();
        }).dimensions(x + half + 4, y, half, 18).build());
        y += 22;

        addPanel(ButtonWidget.builder(Text.literal("Цвет акцента"), b -> {
            int idx = 0;
            for (int i = 0; i < ACCENTS.length; i++) if (ACCENTS[i] == cfg.accent) idx = i;
            cfg.accent = ACCENTS[(idx + 1) % ACCENTS.length];
            cfg.save();
        }).dimensions(x, y, iw, 18).build());
        y += 22;

        addPanel(ButtonWidget.builder(Text.literal("Сбросить всё"), b -> {
            cfg.reset();
            bg.load(cfg);
            clearAndInit();
        }).dimensions(x, y, iw, 18).build());
        y += 26;

        panelH = y - panelY;
        setPanel(panelOpen);
    }

    private <T extends ClickableWidget> T addPanel(T w) {
        addDrawableChild(w);
        panelWidgets.add(w);
        return w;
    }

    private Text particlesText() { return Text.literal("Частицы: " + (cfg.particles ? "вкл" : "выкл")); }
    private Text snapText() { return Text.literal("Сетка: " + (cfg.snap ? "вкл" : "выкл")); }

    private void setPanel(boolean open) {
        panelOpen = open;
        for (ClickableWidget w : panelWidgets) w.visible = open;
        if (!open) {
            setFocused(null);
            cfg.save();
        }
    }

    private void applyPath() {
        String s = pathField.getText().replace("\"", "").trim();
        if (s.isEmpty()) return;
        cfg.bgPath = s;
        cfg.bgType = MenuConfig.isVideo(s) ? MenuConfig.BgType.VIDEO : MenuConfig.BgType.IMAGE;
        cfg.save();
        bg.load(cfg);
    }

    @Override
    public void filesDragged(List<Path> paths) {
        if (paths.isEmpty()) return;
        pathField.setText(paths.get(0).toString());
        applyPath();
    }

    // ================================================================= layout presets

    private void preset(String kind) {
        int W = width, H = height;
        int bw = 140, bh = 20, gap = 4, half = (bw - gap) / 2;

        if (kind.equals("bottom")) {
            String[] ids = {"online", "single", "account", "settings", "quit"};
            int n = ids.length, w = 96;
            int total = n * w + (n - 1) * gap;
            int sx = (W - total) / 2;
            int by = H - bh - H / 12;
            place("title", (W - 170) / 2, by - 56, 170, 44);
            for (int i = 0; i < n; i++) place(ids[i], sx + i * (w + gap), by, w, bh);
            cfg.save();
            return;
        }

        int x0 = switch (kind) {
            case "center" -> (W - bw) / 2;
            case "right" -> W - bw - W / 25;
            default -> W / 25;
        };
        int ty = (int) (H * 0.34f);
        int y = ty + 56;
        place("title", x0, ty, 170, 44);
        place("online", x0, y, bw, bh);
        place("single", x0, y + (bh + gap), bw, bh);
        place("account", x0, y + 2 * (bh + gap), bw, bh);
        place("settings", x0, y + 3 * (bh + gap), half, bh);
        place("quit", x0 + half + gap, y + 3 * (bh + gap), half, bh);
        cfg.save();
    }

    private void place(String id, int x, int y, int w, int h) {
        cfg.pos.put(id, new MenuConfig.Pos((float) x / width, (float) y / height, w, h));
    }

    private void savePos(El e) {
        cfg.pos.put(e.id, new MenuConfig.Pos((float) e.x / width, (float) e.y / height, e.w, e.h));
        cfg.save();
    }

    // ================================================================= render

    @Override
    public void renderBackground(DrawContext ctx, int mx, int my, float delta) {
        // пусто: фон рисуем сами в render()
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        bg.update();
        if (bg.ready()) bg.draw(ctx, width, height);
        else drawDefaultBg(ctx);

        int dimA = (int) (MathHelper.clamp(cfg.dim, 0f, 0.9f) * 255);
        if (dimA > 0) ctx.fill(0, 0, width, height, dimA << 24);
        ctx.fillGradient(0, 0, width, height / 3, 0x88000000, 0x00000000);
        ctx.fillGradient(0, height * 2 / 3, width, height, 0x00000000, 0xAA000000);

        drawTopBar(ctx, mx, my);

        for (El e : els) {
            if (e.id.equals("title")) drawTitle(ctx, e);
            else drawButton(ctx, e, mx, my);
            if (panelOpen) {
                int c = (e == dragging) ? cfg.accent : 0x66FFFFFF;
                ctx.drawBorder(e.x - 1, e.y - 1, e.w + 2, e.h + 2, c);
            }
        }

        if (panelOpen) {
            roundRect(ctx, panelX, panelY, panelW, panelH, 6, 0xF0101216);
            ctx.drawText(textRenderer, "Настройки меню", panelX + 8, panelY + 6, 0xFFFFFFFF, false);
            ctx.drawText(textRenderer, "Фон", panelX + 8, labelBgY, 0xFF8A8F98, false);
            ctx.drawText(textRenderer, "Расположение", panelX + 8, labelLayoutY, 0xFF8A8F98, false);
            ctx.drawText(textRenderer, "Тащи элементы мышью  •  колёсико над кнопкой — ширина",
                    8, height - 14, 0xFFB0B5BD, true);
        }

        super.render(ctx, mx, my, delta); // виджеты панели
    }

    private void drawTopBar(DrawContext ctx, int mx, int my) {
        // аккаунт
        roundRect(ctx, 10, 8, 18, 18, 4, cfg.accent);
        ctx.drawText(textRenderer, "Текущий аккаунт", 34, 8, 0xFF8A8F98, false);
        ctx.drawText(textRenderer, client.getSession().getUsername(), 34, 18, 0xFFFFFFFF, false);

        // часы
        int gx = width - 26, gy = 8;
        int cw = 46, cx = gx - cw - 6;
        roundRect(ctx, cx, gy, cw, 18, 5, 0xB0101216);
        String time = LocalTime.now().format(CLOCK);
        ctx.drawText(textRenderer, time, cx + (cw - textRenderer.getWidth(time)) / 2, gy + 5, 0xFFFFFFFF, false);

        // шестерёнка
        boolean hov = inRect(mx, my, gx, gy, 18, 18);
        int bgc = panelOpen ? cfg.accent : (hov ? 0xE0303540 : 0xB0101216);
        roundRect(ctx, gx, gy, 18, 18, 5, bgc);
        for (int r = 0; r < GEAR.length; r++)
            for (int c = 0; c < GEAR[r].length(); c++)
                if (GEAR[r].charAt(c) == '#') ctx.fill(gx + 4 + c, gy + 4 + r, gx + 5 + c, gy + 5 + r, 0xFFFFFFFF);
    }

    private void drawTitle(DrawContext ctx, El e) {
        String name = client.getSession().getUsername().toUpperCase(Locale.ROOT);
        ctx.getMatrices().push();
        ctx.getMatrices().translate(e.x, e.y, 0);
        ctx.getMatrices().scale(0.75f, 0.75f, 1f);
        ctx.drawText(textRenderer, "РАД ВИДЕТЬ, " + name, 0, 0, 0xFF7C828D, false);
        ctx.getMatrices().pop();

        Text t = Text.literal("Сборка собрана и прогрета — это " + cfg.clientName + ".");
        int y = e.y + 10;
        for (OrderedText line : textRenderer.wrapLines(t, e.w)) {
            ctx.drawText(textRenderer, line, e.x, y, 0xFFFFFFFF, true);
            y += 10;
        }
    }

    private void drawButton(DrawContext ctx, El e, int mx, int my) {
        boolean hov = !panelOpen && inRect(mx, my, e.x, e.y, e.w, e.h);
        e.hover += ((hov ? 1f : 0f) - e.hover) * 0.25f;

        int base = e.primary ? cfg.accent : 0xFF23252B;
        int col = mix(base, 0xFFFFFFFF, e.hover * (e.primary ? 0.18f : 0.10f));
        roundRect(ctx, e.x, e.y, e.w, e.h, 4, (col & 0x00FFFFFF) | 0xE6000000);

        String label = textRenderer.trimToWidth(e.label, e.w - 8);
        int ty = e.y + (e.h - 8) / 2;
        if (e.w >= 100) {
            roundRect(ctx, e.x + 8, e.y + (e.h - 6) / 2, 6, 6, 2, e.primary ? 0xFFFFFFFF : cfg.accent);
            ctx.drawText(textRenderer, label, e.x + 20, ty, 0xFFFFFFFF, false);
        } else {
            ctx.drawText(textRenderer, label, e.x + (e.w - textRenderer.getWidth(label)) / 2, ty, 0xFFFFFFFF, false);
        }
    }

    // ---------------------------------------------------------------- default animated background

    private void drawDefaultBg(DrawContext ctx) {
        float t = (System.currentTimeMillis() - t0) / 1000f;
        float k = (MathHelper.sin(t * 0.08f) + 1f) / 2f; // медленная смена "закат <-> ночь"
        int top = mix(0xFF1A2050, 0xFF070B1F, k);
        int mid = mix(0xFFD9784A, 0xFF2B3A78, k);
        int bot = mix(0xFF2A1A2E, 0xFF0B0E1A, k);
        int split = (int) (height * 0.62f);
        ctx.fillGradient(0, 0, width, split, top, mid);
        ctx.fillGradient(0, split, width, height, mid, bot);

        for (int l = 0; l < 2; l++) {
            int col = l == 0 ? 0xFF18142A : 0xFF0D0A16;
            float base = height * (0.70f + 0.09f * l);
            for (int x = 0; x < width; x += 2) {
                int y = (int) (base + 12 * MathHelper.sin(x * 0.013f + l * 1.7f + t * 0.02f)
                        + 7 * MathHelper.sin(x * 0.034f + l * 3.1f));
                ctx.fill(x, y, x + 2, height, col);
            }
        }

        if (cfg.particles) {
            for (int i = 0; i < 70; i++) {
                float fx = frac(i * 0.6180339f + t * 0.004f * (0.5f + (i % 5) * 0.2f));
                float fy = 0.25f + 0.65f * frac(i * 0.7548776f);
                int px = (int) (fx * width);
                int py = (int) (fy * height + MathHelper.sin(t * 0.6f + i) * 6f);
                float tw = (MathHelper.sin(t * 1.5f + i * 1.3f) + 1f) / 2f;
                int a = (int) (40 + 200 * tw);
                int s = (i % 4 == 0) ? 2 : 1;
                if (s == 2) ctx.fill(px - 1, py - 1, px + 3, py + 3, ((a / 4) << 24) | 0xF2C078);
                ctx.fill(px, py, px + s, py + s, (a << 24) | 0xF2C078);
            }
        }
    }

    // ================================================================= input

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        int x = (int) mx, y = (int) my;
        if (button == 0 && inRect(x, y, width - 26, 8, 18, 18)) {
            click();
            setPanel(!panelOpen);
            return true;
        }
        if (panelOpen) {
            if (super.mouseClicked(mx, my, button)) return true;
            if (inRect(x, y, panelX, panelY, panelW, panelH)) return true;
            if (button == 0) {
                for (int i = els.size() - 1; i >= 0; i--) {
                    El e = els.get(i);
                    if (inRect(x, y, e.x, e.y, e.w, e.h)) {
                        dragging = e;
                        grabDx = x - e.x;
                        grabDy = y - e.y;
                        return true;
                    }
                }
            }
            return false;
        }
        if (button == 0) {
            for (El e : els) {
                if (e.action != null && inRect(x, y, e.x, e.y, e.w, e.h)) {
                    click();
                    e.action.run();
                    return true;
                }
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragging != null && button == 0) {
            int nx = (int) mx - grabDx, ny = (int) my - grabDy;
            if (cfg.snap) {
                nx = Math.round(nx / (float) GRID) * GRID;
                ny = Math.round(ny / (float) GRID) * GRID;
            }
            dragging.x = MathHelper.clamp(nx, 0, Math.max(0, width - dragging.w));
            dragging.y = MathHelper.clamp(ny, 0, Math.max(0, height - dragging.h));
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (dragging != null && button == 0) {
            savePos(dragging);
            dragging = null;
            return true;
        }
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double h, double v) {
        if (panelOpen) {
            for (El e : els) {
                if (!e.id.equals("title") && inRect((int) mx, (int) my, e.x, e.y, e.w, e.h)) {
                    e.w = MathHelper.clamp(e.w + (int) Math.signum(v) * 4, 40, 260);
                    e.x = Math.min(e.x, Math.max(0, width - e.w));
                    savePos(e);
                    return true;
                }
            }
        }
        return super.mouseScrolled(mx, my, h, v);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_ESCAPE && panelOpen) {
            setPanel(false);
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean shouldCloseOnEsc() { return false; }

    @Override
    public void removed() {
        cfg.save();
        bg.close();
    }

    // ================================================================= helpers

    private void click() {
        client.getSoundManager().play(PositionedSoundInstance.master(SoundEvents.UI_BUTTON_CLICK, 1.0f));
    }

    private static boolean inRect(int mx, int my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private static float frac(float v) { return v - MathHelper.floor(v); }

    private static int mix(int a, int b, float t) {
        int ca = (int) MathHelper.lerp(t, a >>> 24, b >>> 24);
        int cr = (int) MathHelper.lerp(t, (a >> 16) & 255, (b >> 16) & 255);
        int cg = (int) MathHelper.lerp(t, (a >> 8) & 255, (b >> 8) & 255);
        int cb = (int) MathHelper.lerp(t, a & 255, b & 255);
        return (ca << 24) | (cr << 16) | (cg << 8) | cb;
    }

    /** Скруглённый прямоугольник из горизонтальных полос. */
    static void roundRect(DrawContext c, int x, int y, int w, int h, int r, int color) {
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        c.fill(x, y + r, x + w, y + h - r, color);
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = r - (int) Math.round(Math.sqrt(r * r - dy * dy));
            c.fill(x + inset, y + i, x + w - inset, y + i + 1, color);
            c.fill(x + inset, y + h - i - 1, x + w - inset, y + h - i, color);
        }
    }

    // ---------------------------------------------------------------- slider

    private final class DimSlider extends SliderWidget {
        DimSlider(int x, int y, int w, int h) {
            super(x, y, w, h, Text.empty(), cfg.dim / 0.9);
            updateMessage();
        }

        @Override
        protected void updateMessage() {
            setMessage(Text.literal("Затемнение: " + (int) (cfg.dim * 100) + "%"));
        }

        @Override
        protected void applyValue() {
            cfg.dim = (float) (value * 0.9);
        }

        @Override
        public void onRelease(double mx, double my) {
            super.onRelease(mx, my);
            cfg.save();
        }
    }
}
