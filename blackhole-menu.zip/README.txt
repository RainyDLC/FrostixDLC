Установка:
1) Скопируй src/ поверх проекта FrostixDLC.
2) В src/main/resources/kimiko.mixins.json добавь в массив "client":
     "BlackHoleTitleScreenMixin",
3) ./gradlew runClient
